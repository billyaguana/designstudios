<?php
/**
 * @version     1.0
 * @package     mod_amcarousel
 * @copyright   Creative Cat Studios.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @author      Billy Aguana <billyaguana@gmail.com> - http://www.billyaguana.com
 */
//No Direct Access
defined('_JEXEC') or die;
$items = 15;
$route = JUri::root(true) . "/";

for ($x = 1; $x <= $items; $x++) {
   $logo[$x] =	htmlspecialchars($params->get('logoClient(' . $x . ')'));	
} 


// Include the syndicate functions only once
require_once dirname(__FILE__).'/helper.php';

require JModuleHelper::getLayoutPath('mod_amcarousel', $params->get('layout', 'default'));
?>