<?php
/**
 * @version     1.0
 * @package     mod_aniconlink
 * @copyright   Creative Cat Studios.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @author      Billy Aguana <billyaguana@gmail.com> - http://www.billyaguana.com
 */

//No Direct Access
defined('_JEXEC') or die;
?>

<div class="<?php echo $iconClass; ?> row-item">
  <div class="wrapper <?php echo $wrapClass; ?>">
    <a href="<?php echo $iconLink; ?>">
    <div class="card-img pb-3 align-center">
      <span><?php echo $linkIcon; ?></span>
    </div>
    <h4 class="card-title align-center"><?php echo $linkText; ?></h4>
    </a>
  </div>
</div>
