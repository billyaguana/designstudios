<?php
/**
 * @version     1.0
 * @package     mod_ateambox
 * @copyright   Creative Cat Studios.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @author      Billy Aguana <billyaguana@gmail.com> - http://www.billyaguana.com
 */

//No Direct Access
defined('_JEXEC') or die;
?>
<div class="member p-3 col-12 col-md-6 col-lg-3">
  <div class="wrapper <?php echo $extraClass; ?>">
  <div class="mb-5">
      <img class="img-icon" src="<?php echo $memberImage; ?>" alt="<?php echo $memberName; ?>">
  </div>
  <div class="desc">
      <h5 class="name"><?php echo $memberName; ?></h5>
      <h6 class="position"><?php echo $memberPosition; ?></h6>
      <p><i class="fas fa-quote-left"></i> <?php echo $memberQuote; ?></p>
      <p class="social-link">
        <?php if($facebookLink) { ?>
         <a href="<?php echo $facebookLink; ?>"><i class="fab fa-facebook"></i></a>
        <?php } if($twitterLink) { ?>
         <a href="<?php echo $twitterLink; ?>"><i class="fab fa-twitter"></i></a>
        <?php } if($instagramLink) { ?>        
         <a href="<?php echo $instagramLink; ?>"><i class="fab fa-instagram"></i></a>                  
        <?php } ?>
      </p>
  </div>
  </div>
</div>