<?php
/**
 * @version     1.0
 * @package     mod_ateambox
 * @copyright   Creative Cat Studios.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @author      Billy Aguana <billyaguana@gmail.com> - http://www.billyaguana.com
 */
//No Direct Access
defined('_JEXEC') or die;

/* Params */
$memberImage = 		$params->get('memberImage');
$memberImage = 		JUri::root(true) . "/" . $memberImage;

$extraClass = 		htmlspecialchars($params->get('extraClass'));
$memberName = 		htmlspecialchars($params->get('memberName'));
$memberPosition = 	htmlspecialchars($params->get('memberPosition'));
$memberQuote =  	htmlspecialchars($params->get('memberQuote'));

$facebookLink =     $params->get('FacebookLink');
$twitterLink = 		$params->get('TwitterLink');
$instagramLink = 	$params->get('InstagramLink');

// Include the syndicate functions only once
require_once dirname(__FILE__).'/helper.php';

require JModuleHelper::getLayoutPath('mod_ateambox', $params->get('layout', 'default'));
?>