<?php
/**
 * @version     1.0
 * @package     mod_aniconbox
 * @copyright   Creative Cat Studios.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @author      Billy Aguana <billyaguana@gmail.com> - http://www.billyaguana.com
 */

//No Direct Access
defined('_JEXEC') or die;
?>
<div class="box-item <?php echo $moduleclass_sfx; ?>">
    <div class="icon-block-top pb-4">
      <span><?php echo $headingicon; ?></span>
    </div>
    <h4 class="box-item-title pb-3">
        <?php echo $headingtext; ?>
    </h4>
    <p><?php echo $paragraphtext; ?></p>
	<?php if($show_read_more) : ?>
    <div class="section-btn">
        <a class="mr-3" href="<?php echo $read_more_link; ?>">
            <?php echo $read_more_icon; ?> <?php echo $read_more_text; ?>
        </a>
    </div>
    <?php endif; ?>
</div>