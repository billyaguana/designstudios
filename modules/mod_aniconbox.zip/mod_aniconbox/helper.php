<?php
/**
 * @version     1.0
 * @package     mod_aniconbox
 * @copyright   Creative Cat Studios.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @author      Billy Aguana <billyaguana@gmail.com> - http://www.billyaguana.com
 */

//No Direct Access
defined('_JEXEC') or die;

class modBootstrapBlockHelper{
   
}
?>