<?php
/**
 * @version     1.0
 * @package     mod_ateambox
 * @copyright   Creative Cat Studios.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @author      Billy Aguana <billyaguana@gmail.com> - http://www.billyaguana.com
 */

//No Direct Access
defined('_JEXEC') or die;
?>

<div class="col-md-6 col-lg-4">
<!-- Card -->
<div class="card m-3 z-depth-0">
  <div class="view overlay">
    <img class="card-img-top" src="<?php echo $projectImage; ?>" alt="<?php echo $projectName; ?>">
    <a href="<?php echo $projectLink; ?>">
      <div class="mask rgba-cyan-slight"></div>
    </a>
  </div>
  <div class="card-body">
    <h4 class="card-title"><?php echo $projectName; ?></h4>
    <hr>
    <p class="card-text"><?php echo $projectText; ?></p>
  </div>
  <div class="rounded-bottom cyan pt-3">
      <ul class="list-unstyled list-inline font-small clearfix">
        <li class="list-inline-item ml-4 float-left">
          <span class="white-text proj-type">PROJECT : <?php echo $projectType; ?></span>
        </li>    
        <li class="list-inline-item mr-4 float-right">
          <a href="<?php echo $projectLink; ?>" class="white-text btn-view">VIEW PROJECT </a>
        </li>
      </ul>
  </div>
</div>
<!-- Card -->
</div> 