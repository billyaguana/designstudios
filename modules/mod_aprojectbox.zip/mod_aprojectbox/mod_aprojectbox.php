<?php
/**
 * @version     1.0
 * @package     mod_aprojectbox
 * @copyright   Creative Cat Studios.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @author      Billy Aguana <billyaguana@gmail.com> - http://www.billyaguana.com
 */
//No Direct Access
defined('_JEXEC') or die;

/* Params */
$projectImage = 		$params->get('projectImage');
$projectImage = 		JUri::root(true) . "/" . $projectImage;

$projectName = 		htmlspecialchars($params->get('projectName'));
$projectText =  	htmlspecialchars($params->get('projectText'));
$projectType =  	htmlspecialchars($params->get('projectType'));
$projectLink =     $params->get('projectLink');

// Include the syndicate functions only once
require_once dirname(__FILE__).'/helper.php';

require JModuleHelper::getLayoutPath('mod_aprojectbox', $params->get('layout', 'default'));
?>