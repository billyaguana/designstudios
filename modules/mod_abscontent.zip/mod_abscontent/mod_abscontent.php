<?php
/**
 * @version     1.0
 * @package     mod_abscontent
 * @copyright   Creative Cat Studios.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @author      Billy Aguana <billyaguana@gmail.com> - http://www.billyaguana.com
 */
//No Direct Access
defined('_JEXEC') or die;

/* Params */
$contentTitle = 	htmlspecialchars($params->get('contentTitle'));
$contentImage = 	$params->get('contentImage');
$dcontentImage =     '<img src="' . $contentImage . '" alt="' . $contentTitle . '">';
$contentLe =  		$params->get('contentLe');

$show_read_more =  	$params->get('show_read_more',1);
$read_more_text =  	htmlspecialchars($params->get('read_more_text'));
$read_more_link =  	htmlspecialchars($params->get('read_more_link'));

// Include the syndicate functions only once
require_once dirname(__FILE__).'/helper.php';

require JModuleHelper::getLayoutPath('mod_abscontent', $params->get('layout', 'default'));
?>