<?php
/**
 * @version     1.0
 * @package     mod_abscontent
 * @copyright   Creative Cat Studios.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @author      Billy Aguana <billyaguana@gmail.com> - http://www.billyaguana.com
 */

//No Direct Access
defined('_JEXEC') or die;

if($contentImage) {
	$bclass = 'col-lg-6';
} else {
	$bclass = 'col-lg-12';
}
?>

<div class="about">  
<div class="container">
      <div class="row">
          <div class="text-content mb-4 <?php echo $bclass; ?>">
              <h2 class="mb-4"><?php echo $contentTitle; ?></h2>
              <?php echo $contentLe; ?>
              
              <?php if($show_read_more) : ?>
              <div class="align-left">
                <a class="btn btn-cyan btn-md" href="<?php echo $read_more_link; ?>">
				  <?php echo $read_more_text; ?>
                </a>
              </div>
              <?php endif; ?>
          </div>
   		  
          <?php if($contentImage) : ?>	
          <div class="mbr-figure col-lg-6">
              <?php echo $dcontentImage; ?>
          </div>
          <?php endif; ?>

      </div>
</div>
</div>