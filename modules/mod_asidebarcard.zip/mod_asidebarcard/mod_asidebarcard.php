<?php
/**
 * @version     1.0
 * @package     mod_asidebarcard
 * @copyright   Creative Cat Studios.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @author      Billy Aguana <billyaguana@gmail.com> - http://www.billyaguana.com
 */
//No Direct Access
defined('_JEXEC') or die;

/* Params */
$cardImage = 	 $params->get('cardImage');
$cardImage = 	 JUri::root(true) . "/" . $cardImage;

$show_image =     $params->get('show_image');

$cardTitle = 	 htmlspecialchars($params->get('cardTitle'));
$cardText = 	 htmlspecialchars($params->get('cardText'));

$cardLinkText1 = htmlspecialchars($params->get('cardLinkText1'));
$cardLink1 =     $params->get('cardLink1');

$cardLinkText2 = htmlspecialchars($params->get('cardLinkText2'));
$cardLink2 =     $params->get('cardLink2');

$blockText1 =  	 htmlspecialchars($params->get('blockText1'));
$blockText2 =    htmlspecialchars($params->get('blockText2'));
$blockText3 =  	 htmlspecialchars($params->get('blockText3'));

// Include the syndicate functions only once
require_once dirname(__FILE__).'/helper.php';

require JModuleHelper::getLayoutPath('mod_asidebarcard', $params->get('layout', 'default'));
?>