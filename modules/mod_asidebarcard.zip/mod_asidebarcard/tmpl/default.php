<?php
/**
 * @version     1.0
 * @package     mod_asidebarcard
 * @copyright   Creative Cat Studios.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @author      Billy Aguana <billyaguana@gmail.com> - http://www.billyaguana.com
 */

//No Direct Access
defined('_JEXEC') or die;
?>

<div class="card z-depth-0">
  <?php if($show_image) { ?>
    <img src="<?php echo $cardImage; ?>" class="card-img-top" alt="<?php echo $cardTitle; ?>">
  <?php } ?>
  
  <div class="card-body">
    <h5 class="card-title"><?php echo $cardTitle; ?></h5>
    <p class="card-text"><?php echo $cardText; ?></p>
  </div>
  <ul class="list-group list-group-flush">
    <?php if($blockText1) { ?><li class="list-group-item"><?php echo $blockText1 ?></li><?php } ?>
    <?php if($blockText2) { ?><li class="list-group-item"><?php echo $blockText2 ?></li><?php } ?>
    <?php if($blockText3) { ?><li class="list-group-item"><?php echo $blockText3 ?></li><?php } ?>
  </ul>
  <div class="card-body">
    <?php if($cardLink1) { ?><a href="<?php echo $cardLink1 ?>" class="card-link"><?php echo $cardLinkText1; ?></a><?php } ?>
    <?php if($cardLink2) { ?><a href="<?php echo $cardLink2 ?>" class="card-link"><?php echo $cardLinkText2; ?></a><?php } ?>
  </div>
</div>