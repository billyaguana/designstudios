<?php
defined('_JEXEC') or die;

$app = JFactory::getApplication();
$doc = JFactory::getDocument();
$user = JFactory::getUser();

// Getting params from template
$params = $app->getTemplate(true)->params;

// Detecting Active Variables
$option = $app->input->getCmd('option', '');
$view = $app->input->getCmd('view', '');
$layout = $app->input->getCmd('layout', '');
$task = $app->input->getCmd('task', '');
$itemid = $app->input->getCmd('Itemid', '');
$sitename = $app->get('sitename');

if ($task == "edit" || $layout == "form") {
    $fullWidth = 1;
} else {
    $fullWidth = 0;
}


$my_folder = $this->baseurl . '/templates/' . $this->template;

// Add Stylesheets
$doc->addStyleSheet('https://use.fontawesome.com/releases/v5.6.1/css/all.css');
$doc->addStyleSheet($my_folder . '/assets/css/bootstrap.min.css');
$doc->addStyleSheet($my_folder . '/assets/css/mdb.min.css');
// Style 
$doc->addStyleSheet($my_folder . '/assets/css/carousel.css');
$doc->addStyleSheet($my_folder . '/css/template.css');

// Add Javascript
JHtml::_('jquery.framework');
//$doc->addScript($my_folder . '/assets/js/jquery-3.3.1.min.js');
$doc->addScript($my_folder . '/assets/js/popper.min.js');
$doc->addScript($my_folder . '/assets/js/bootstrap.min.js');
$doc->addScript($my_folder . '/assets/js/parallax.min.js');
$doc->addScript($my_folder . '/assets/js/jquery.backstretch.min.js');

$doc->addScript($my_folder . '/assets/js/multislider.min.js');

$doc->addScript($my_folder . '/assets/js/main.js');

// Template Details XML
$favicon = 			$this->params->get('favicon');
$favicon = 			JUri::root(true) . "/" . $favicon;
$headerBG = 		$this->params->get('headerBG');
$headerBG = 		JUri::root(true) . "/" . $headerBG;
$logoFile = 		$this->params->get('logoFile');

$show_article =	 	$this->params->get('show_article');

$companyName =	 	htmlspecialchars($this->params->get('companyName'));
$bannerTitle = 		htmlspecialchars($this->params->get('bannerTitle'));
$bannerText = 		htmlspecialchars($this->params->get('bannerText'));
$serviceTitle = 	htmlspecialchars($params->get('serviceTitle'));
$serviceText = 		htmlspecialchars($params->get('serviceText'));
$teamTitle = 		htmlspecialchars($params->get('teamTitle'));
$teamText = 		htmlspecialchars($params->get('teamText'));
$projectTitle = 	htmlspecialchars($params->get('projectTitle'));
$carouselTitle = 	htmlspecialchars($params->get('carouselTitle'));

$carouselBG = 		$this->params->get('carouselBG');
$carouselBG = 		JUri::root(true) . "/" . $carouselBG;


//Social Links
$facebookLink =     $this->params->get('FacebookLink');
$twitterLink = 		$this->params->get('TwitterLink');
$instagramLink = 	$this->params->get('InstagramLink');

$footerImage = 		$this->params->get('footerImage');
$footerImage = 		JUri::root(true) . "/" . $footerImage;

$footerImageLink =	htmlspecialchars($params->get('footerImageLink'));

$contactAddress1 =	htmlspecialchars($params->get('contactAddress1'));
$contactAddress2 =	htmlspecialchars($params->get('contactAddress2'));
$contactPhone =		htmlspecialchars($params->get('contactPhone'));
$contactEmail =		htmlspecialchars($params->get('contactEmail'));

$copyright = 		htmlspecialchars($params->get('copyright'));

if ($this->countModules('modbannerboxes'))  { 
    $bannerclass = 'banner';     
} else { 
    $bannerclass = 'banner-inner'; 
} 

$menu = $app->getMenu();
if ($menu->getActive() == $menu->getDefault()) {
    $page = 'frontpage';	
} else {
	$page = 'subpage';	
}

// Adjusting content width
/*
if ($this->countModules('sidebar-left') && $this->countModules('sidebar-right')) {
    $span = "col-md-6";
} elseif ($this->countModules('sidebar-left') && !$this->countModules('sidebar-right')) {
    $span = "col-md-9";
} elseif (!$this->countModules('sidebar-left') && $this->countModules('sidebar-right')) {
    $span = "col-md-9";
} else {
    $span = "col-md-12";
}*/
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <jdoc:include type="head" />
  <link rel="icon" href="<?php echo $favicon; ?>" />
</head>

<body>
  <header>

  <div class="parallax-window mask rgba-black-strong" data-parallax="scroll" 
  data-image-src="<?php echo $headerBG;  ?>">
    
    <div class="<?php echo $bannerclass; ?>">

    <!-- /* NAVIGATION */ -->
      <nav class="navbar z-depth-0 fixed-top navbar-expand-lg navbar-dark scrolling-navbar">
        <a class="navbar-brand" href="<?php echo JURI::base(); ?>">
            <?php if($logoFile) : ?>
             <img src="<?php echo $logoFile; ?>" alt="<?php echo $companyName; ?>">
            <?php endif; ?>
            <strong><?php echo $companyName; ?></strong>
        </a>
        
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
          aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        
        <div class="collapse navbar-collapse" id="navbarSupportedContent">

          <jdoc:include type="modules" name="main-menu" style="none" />
                
          <ul class="navbar-nav nav-flex-icons">
            <li class="nav-item">
              <a class="nav-link" href="<?php echo $facebookLink; ?>" target="_blank">
                  <i class="fab fa-facebook-f"></i>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="<?php echo $twitterLink; ?>" target="_blank">
                  <i class="fab fa-twitter"></i>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="<?php echo $instagramLink; ?>" target="_blank">
                  <i class="fab fa-instagram"></i>
              </a>
            </li>
          </ul>
        </div>
      </nav>
    
      <!-- /* BOXES */ -->
      <div class="container slogan">
          <h1 class="head-title text-center mb-3 fadeIn animated"><?php echo $bannerTitle; ?></h1>
          <p class="text-center"><?php echo $bannerText; ?></p>
      </div>
    </div> <!-- container -->     

  </div> <!-- parallax --> 

    <!-- /* BOXES */ -->
    <?php if ($this->countModules('modbannerboxes') and $view != 'article' and $view != 'category') : ?>      
    <div class="container-boxes">
        <jdoc:include type="modules" name="modbannerboxes" style="none" />  
    </div> <!-- container boxes -->
    <?php endif; ?>  

  </header>
  
  <main>

<!--    <div class="row">
        <div class="mb-4 col-lg-8 p-4"> -->


	<?php if($page == 'frontpage' and $show_article == 1 or $view == 'category') { ?>
	<div class="mwrapper">
      <div class="container mcontent">
			<jdoc:include type="modules" name="positionl" style="none" />           
        	<jdoc:include type="message" />
        	<jdoc:include type="component" />
			<jdoc:include type="modules" name="position2" style="none" />           
      </div>  
      <hr>
    </div>
    <?php } ?>  


	<?php if($page != 'frontpage' and $view != 'category') { ?>
	<div class="mwrapper">
      <div class="container mcontent">
       <div class="row">
          
          <div class="col-lg-8 p-4">     
			<jdoc:include type="modules" name="positionl" style="none" />           
        	<jdoc:include type="message" />
        	<jdoc:include type="component" />
			<jdoc:include type="modules" name="position2" style="none" />           
          </div>  

          <div class="col-lg-4 sidebar p-4">
	   	  <?php if ($this->countModules('sidebar')) : ?>    
			 <jdoc:include type="modules" name="sidebar" style="none" />           
          <?php else: ?>   
          	 <p class="text-center mt-5">No sidebar? why not create a sidebar in the module panel found in the admin.</p>
          <?php endif; ?>   
          </div><!-- sidebar -->
          
        </div><!-- row --> 
      </div><!-- container -->   
      <hr>
    </div>
    <?php } ?>  
	

  	<!-- /* ABOUT */ -->
	<?php if ($this->countModules('modcontent')) : ?>    
	    <jdoc:include type="modules" name="modcontent" style="none" /> 	       
	<?php endif; ?>

    <!-- /* SERVICES ICONS */ -->
    <?php if ($this->countModules('modservices')) : ?>        
    <section class="container services">
      <div class="head-title">
        <h3 class="title-header"><?php echo $serviceTitle; ?></h3>
        <p><?php echo $serviceText; ?></p>
      </div>

      <div class="row justify-content-center pt-4">
	    <jdoc:include type="modules" name="modservices" style="none" /> 	       
      </div><!-- .services -->
    </section>
    <?php endif; ?>


    <!-- /* OUR TEAM */ -->
    <?php if ($this->countModules('modteam')) : ?>   
    <div class="our-team">
      <div class="container">
          <h3 class="title-header"><?php echo $teamTitle; ?></h3>
          <?php if($teamText): ?>
            <p class="title-sub"><?php echo $teamText; ?></p>
          <?php endif; ?>
          <div class="row justify-content-center pt-4">
			
            <jdoc:include type="modules" name="modteam" style="none" /> 
          
          </div>
      </div>  
    </div>  <!-- our team -->
    <?php endif; ?>   


    <!-- /* CLIENT LIST */ -->
    <?php if ($this->countModules('modcarousel')) { ?>  
    <div class="client-list">
    <div class="parallax-window mask rgba-black-strong" data-parallax="scroll" 
    data-image-src="<?php echo $carouselBG;  ?>">
      <div class="container clients">
        <h3 class="mb-5 title-header"><?php echo $carouselTitle; ?></h3>
        
        <div id="mixedSlider">
          <div class="MS-content">

			<jdoc:include type="modules" name="modcarousel" style="none" /> 

          </div>
          <div class="MS-controls">
              <button class="MS-left"><i class="fa fa-angle-left" aria-hidden="true"></i></button>
              <button class="MS-right"><i class="fa fa-angle-right" aria-hidden="true"></i></button>
          </div>
        </div>        
     
      </div>
    </div><!-- .container -->
    </div><!-- .client-list -->
    <?php } else { ?>
    <div class="parallax-window mask rgba-black-strong dnone" data-parallax="scroll" data-image-src="">
    </div>   
    <?php } ?>


   <!-- /* PROJECT */ -->
    <?php if ($this->countModules('modproject')) : ?>   
    <div class="container project">
     <h3 class="title-header mb-2"><?php echo $projectTitle; ?></h3>
     <div class="row justify-content-center pt-4"> 
     
       <jdoc:include type="modules" name="modproject" style="none" /> 

     </div> <!-- row -->
    </div>  <!-- featured blog -->   
    <?php endif; ?>
</main>

<footer class="footer mt-5">
  <div class="wrap">
    <div class="container">
        <div class="row">
            
            <div class="col-12 col-lg-3 col-md-6">
                <div class="media-wrap">
                    <a href="<?php echo $footerImageLink; ?>">
                      <img src="<?php echo $footerImage; ?>" alt="<?php echo $companyName; ?>">
                    </a>
                </div>
            </div>
            
            <div class="col-12 col-lg-3 col-md-6">
                <div class="ml-3">
                <h5 class="pb-3 column-title">Address</h5>
                <div class="list-item">
                   <p><?php echo $contactAddress1; ?><br><?php echo $contactAddress2; ?></p>
                </div>
                <div class="list-item">
                   <p><?php echo $contactPhone; ?></p>
                </div>
                </div>    
            </div>

            <div class="col-12 col-lg-3 col-md-6">
                <h5 class="pb-3 column-title ml-3">Links</h5>
				<jdoc:include type="modules" name="footer-link" style="none" /> 
            </div>
            
            <div class="col-12 col-lg-3 col-md-6">
              <h5 class="pb-3 column-title ml-3">Social Links</h5>
              <p class="social-link clearfix">
                  <a href="<?php echo $facebookLink; ?>" target="_blank">
                      <i class="fab fa-facebook"></i>
                  </a>
                  <a href="<?php echo $twitterLink; ?>" target="_blank">
                      <i class="fab fa-twitter"></i>
                  </a>
                  <a href="<?php echo $instagramLink; ?>" target="_blank">
                      <i class="fab fa-instagram"></i>
                  </a>                  
              </p>
              <p>Email us at : <?php echo $contactEmail; ?></p>    
            </div>

        </div>
      </div>
      
      <div class="container">
        <p class="copyright pt-4 ml-3"><?php echo $copyright; ?></p>
      </div>

   </div> <!-- wrap -->
   
</footer>
<script src="<?php echo $my_folder; ?>/assets/js/mdb.min.js"></script>    
</body>
</html>
